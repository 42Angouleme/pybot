#!/usr/bin/env python3.10

from module import a_function, a_class

a_function(1, 2)
a_function(1, "abc")

var = a_class("abc")
var.print_arg()

an_array = []

an_array.append(1)
an_array.append(2)
an_array.append(3)
an_array.append(4)
an_array.append(5)

for item in an_array:
	print(f"{item = }")

string = "une string"

for char in string:
	print(char, end='')

from pprint import pprint

an_dictionary = {
	"key_1": [
		[0, 0, 0, 0, 0, 0, 0, ],
		[0, 0, 0, 0, 0, 0, 0, ],
		[0, 0, 0, 0, 0, 0, 0, ],
		[0, 0, 0, 0, 0, 0, 0, ],
		{
			"key_2" : {
				"key_3" : True,
				"key_4" : [],
			}
		}
	],
}
print(an_dictionary)
pprint(an_dictionary)

key = "test"
"key = {}".format(key)

# an_dictionary["key_3"] = "value_3"
# an_dictionary["key_4"] = "value_4"

for key, value in an_dictionary.items():
	print(f"{key = }|{value = }")

an_array_of_tuple = [
	("string", 1),
	("string 2", 2)
]

0b1111_1111
0xff

# if 1 == 1:
# 	print("1==1")
# else:
# 	print("1!=1")

# if 1 == 1 and 2 == 2:
# 	print("1==1")
# else:
# 	print("1!=1")

