#!/usr/bin/env python3.10

# class parent:
# 	def __init__(self):
# 		print(1)

import timeit

class a_class:
	def __init__(self, arg):
		self.arg = arg

	def print_arg(self):
		print(self.arg)
		return 1, 2

	def print_2_arg(self, arg_2):
		print(self.arg)
		print(arg_2)

	@staticmethod
	def print_3_arg(arg_3):
		print(arg_3)

def a_function(arg_1, arg_2=2):
	"""
		Function
		--------
		a Description
	"""
	print(arg_1)
	print(arg_2)

array = [
	1,
	2,
]

try:
	a[2]
except IndexError:
	print("Index Error")
except:
	print("Unknown Error")

print(type(a))
print(isinstance(a, int))

if __name__ == "__main__":
	var = a_class(123)
	x, y = var.print_arg()

	var.print_2_arg(123)
	var.print_2_arg("123")

	a_class.print_3_arg(123)
	a_class.print_3_arg("123")

timeit.timeit(a_function, 1)
# this is a commentary

